CAMPUS SHIKAYAT SETU — COLLEGE SUBMISSION PACKAGE

This package contains the runnable application, project report, project
diagrams, and presentation. Project data shown in the documents is illustrative.

PROJECT DOCUMENTS
- report/CampusShikayatSetu_MCA-Mini-Project_Report.pdf
- report/CampusShikayatSetu_MCA-Mini-Project_Report.docx
- report/Campus_Shikayat_Setu_Use_Case_Diagrams.pdf and .docx
- report/Campus_Shikayat_Setu_Project_Diagrams.pdf and .docx
- report/diagrams/ contains editable diagrams.net source files
- presentation/CampusShikayatSetu_MCA-Mini-Project_Review.pptx

Before submission, add your roll number and confirmed guide to the report and
presentation. The college certificate must be issued and signed by the college;
review the declaration for accuracy before signing. In the editable report, open
in Word and update page-reference fields (Ctrl+A, then F9); inspect pagination.
Check with the college whether Semester I and the required binding are correct.
The PDF uses font fallbacks for characters absent from the supplied template.

RUN THE APPLICATION
1. Extract the ZIP fully. Install Python 3.10 or newer (3.11/3.12 recommended).
   On Windows, select "Add Python to PATH" when installing Python.
2. Open the extracted shikayat-setu folder in VS Code. Choose Terminal > Run
   Task > Start Campus Shikayat Setu. Alternatively, double-click
   Start_Project.bat on Windows or run sh start-project.sh on macOS/Linux.
3. On the first run, the launcher creates .venv and installs dependencies;
   internet or locally available packages are normally needed. It reuses the
   environment on later runs. Keep the terminal open until finished.
4. Visit http://127.0.0.1:5001 on the same computer. Press Ctrl+C in the
   terminal to stop. Native Windows execution was not tested in this environment.

DEMONSTRATION ACCOUNTS
Admin:   admin / admin123
Student: MCA2026001 / student123
Officer: hostel.officer / officer123

A new database is created and seeded only if needed, at app/shikayat_setu.db.
Existing data is not reset by the launcher. This ZIP does not contain a database
or a prebuilt .venv. The seeded names and complaints are synthetic examples.
Demo credentials and the development server are not suitable for production.
