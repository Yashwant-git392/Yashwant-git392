# Diagram notes — Campus Shikayat Setu

The college's report sequence lists an ER diagram, use-case diagram, class diagram, activity diagram, deployment diagram and module hierarchy. These diagrams describe the implemented application, not a proposed rewrite. Their editable `.drawio` sources were generated programmatically; they are diagrams.net documents, not manually drawn StarUML or EdrawMax files. The six indexed diagram types and matching PNGs are generated together by `build_corrected_diagrams.py`. The separate architecture image was generated with `build_drawio.py` and rendered with diagrams.net.

## Reading the figures

- **ERD:** The three pages in `fig-erd.drawio` use Chen-style rectangles, relationship diamonds and selected attribute ovals. Underlined `id` is the key. `(min,max)` denotes the number of relationships in which an instance of the adjacent entity participates; `N` means many. Together they cover the schema's eight foreign keys; the department–complaint relationship is repeated for context. Refer to report section 3.3 for all columns and constraints. User department and event actor are nullable. Each complaint has at most one feedback row. Separate assigned department and category permit administrative reassignment.
- **Use case:** Four pages for Student, Officer, Administrator and Public visitor. Only the first three are stored user roles. The admin can also perform officer actions. Its feedback route accepts admin requests but there is no admin feedback form in the interface. Public tracking normally requires a complaint code and matching roll number.
- **Class:** Two pages form a conceptual domain model covering all eight schema associations and multiplicities, not a claim that the project defines Python ORM classes. It does not invent operations.
- **Activity:** Five scoped UML activity pages cover submission, officer/admin resolution, student feedback, student reopening and admin force-close. Rejection and stale-update paths are shown separately; no concurrency or automatic continuation between separate activities is implied. Acknowledgement and starting work are optional before resolution. The reopening code checks whole-day age, and force-close does not enforce a waiting period.
- **Deployment:** A local single-computer demonstration of a browser, Python/Flask environment and SQLite file. LAN access is optional and depends on local settings. The server is not a production deployment.
- **Module hierarchy:** Project files grouped by responsibility; the lines indicate grouping rather than direct imports. There are no Flask blueprints or background workers.

`Campus_Shikayat_Setu_Project_Diagrams.pdf` and its DOCX companion provide 16 larger, separate pages for viewing or printing. The report still contains the diagrams and descriptions under the required index sections. Diagram elements in the Word document are images; edit the `.drawio` files to change individual shapes.

## Editing and rebuilding

1. Open the `.drawio` files in diagrams.net (desktop or web). `fig-erd.drawio` has three pages; `fig-usecase.drawio` has four, `fig-class.drawio` has two, and `fig-activity.drawio` has five. These documents use fixed-point connectors: move lines as well as shapes when editing and recheck relationships.
2. Programmatic rebuilding overwrites generated sources. To rebuild the six indexed diagram types and their matching PNGs, install `requirements-report.txt` and run `python report/build_corrected_diagrams.py` from the project directory. Run `python report/build_drawio.py` to rebuild all seven editable source documents; this does not export PNGs; the architecture PNG is maintained separately.
3. Run `python report/build_diagram_collection.py` to update the larger PDF and DOCX collection. Rebuild the project report PDF and DOCX as described in `REPORT_FORMAT.md`, using a disposable seeded database. Run diagram and report validators, visually review every page and check Word pagination before submission.

The generator checks the SQLite schema's eight foreign keys, feedback uniqueness and optional relationship columns. It cannot replace an independent review of visual notation, code behavior, and college-specific requirements.
